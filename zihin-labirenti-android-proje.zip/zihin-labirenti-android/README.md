# Zihin Labirenti

Android WebView wrapper for the offline Zihin Labirenti prototype.

## Build
The GitHub Actions workflow builds:
- A debug APK for device testing.
- An unsigned release AAB for the later signing step.

The AAB is **not ready for Play Store upload** until it is signed with a private upload key and the Play Console setup is complete.

Package: `com.zihinlabirenti.app`
Target SDK: 36
